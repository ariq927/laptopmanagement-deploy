<?php
  $contentNavbar = $contentNavbar ?? true;
  $containerNav = $containerNav ?? 'container-xxl';
  $isNavbar = $isNavbar ?? true;
  $isMenu = $isMenu ?? true;
  $isFlex = $isFlex ?? false;
  $isFooter = $isFooter ?? true;
  $container = $container ?? 'container-xxl';
?>

<?php $__env->startSection('layoutContent'); ?>
  
  <script>
    (function() {
      const isDark =
        localStorage.getItem('theme') === 'dark' ||
        (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);

      document.documentElement.style.backgroundColor = isDark ? '#0e141b' : '#fff';
      document.body.style.backgroundColor = isDark ? '#0e141b' : '#fff';
      document.documentElement.classList.toggle('dark-mode', isDark);
    })();
  </script>

  <style>
    /* Default dark background while Vite/React loads */
    html, body {
      background-color: #0e141b;
      color: #fff;
      transition: background-color 0s ease !important;
    }
    .layout-wrapper {
      background-color: transparent !important;
      transition: none !important;
    }
  </style>
  

  <div class="layout-wrapper layout-content-navbar <?php echo e($isMenu ? '' : 'layout-without-menu'); ?>">
    <div class="layout-container">
      <?php if($isMenu): ?>
        <?php echo $__env->make('layouts/sections/menu/verticalMenu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <?php endif; ?>

      <div class="layout-page">
        <?php if($isNavbar): ?>
          <?php echo $__env->make('layouts/sections/navbar/navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <div class="content-wrapper">
          <div class="<?php echo e($container); ?> flex-grow-1 container-p-y">
            <?php echo $__env->yieldContent('content'); ?>
          </div>

          <?php if($isFooter): ?>
            <?php echo $__env->make('layouts/sections/footer/footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php if($isMenu): ?>
      <div class="layout-overlay layout-menu-toggle"></div>
    <?php endif; ?>
    <div class="drag-target"></div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/commonMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\projects\laptop-management-Deploy\resources\views/layouts/contentNavbarLayout.blade.php ENDPATH**/ ?>