<?php $__env->startSection('title', 'Login - Laptop Management PLN IPS'); ?>

<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/scss/pages/page-auth.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl">
  <div class="authentication-wrapper authentication-basic container-p-y">
    <div class="authentication-inner">
      <div class="card px-sm-6 px-0">
        <div class="card-body">
          <h4 class="mb-1">Selamat Datang 👋</h4>
          <p class="mb-6">Silakan login menggunakan akun LDAP Anda.</p>

          <?php if($errors->any()): ?>
            <div class="alert alert-danger mt-3">
              <?php echo e($errors->first()); ?>

            </div>
          <?php endif; ?>

          <form action="<?php echo e(route('auth-login-basic-post')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-6">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
            </div>

            <div class="mb-6 form-password-toggle">
              <label class="form-label" for="password">Password</label>
              <div class="input-group input-group-merge">
                <input type="password" id="password" class="form-control" name="password" required>
                <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
              </div>
            </div>

            <button class="btn btn-primary d-grid w-100" type="submit">Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\projects\laptop-management-Deploy\resources\views/content/authentications/auth-login-basic.blade.php ENDPATH**/ ?>