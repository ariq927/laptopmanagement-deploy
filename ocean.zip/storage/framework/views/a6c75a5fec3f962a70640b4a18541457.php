<?php $__env->startSection('title', 'Daftar Peminjam Laptop'); ?>


<?php $__env->startSection('page-style'); ?>
<style>
  .layout-wrapper {
    background: url('/assets/img/backgrounds/plnn.jpg') no-repeat center center fixed !important;
    background-size: cover !important;
  }

  .layout-page,
  .content-wrapper {
    background: transparent !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  
    <div id="react-peminjam-table"
         data-search="<?php echo e(request('search')); ?>"
         data-per-page="<?php echo e($perPage ?? 10); ?>">
    </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\projects\laptop-management-Deploy\resources\views/content/tables/tables-basic.blade.php ENDPATH**/ ?>