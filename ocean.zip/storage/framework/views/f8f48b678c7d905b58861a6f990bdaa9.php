<?php $__env->startSection('title', 'Dashboard - Laptop Management PLN IPS'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/apexcharts@3.44.0/dist/apexcharts.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="https://cdn.jsdelivr.net/npm/apexcharts@3.44.0"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<style>
  .layout-wrapper {
    background: url('/assets/img/backgrounds/bg2.jpg') no-repeat center center fixed !important;
    background-size: cover !important;
  }
  .layout-page,
  .content-wrapper {
    background: transparent !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script>
  window.dashboardData = {
    user: <?php echo json_encode($user, 15, 512) ?>,
    totalLaptop: <?php echo e($totalLaptop ?? 0); ?>,
    tersedia: <?php echo e($tersedia ?? 0); ?>,
    diarsip: <?php echo e($diarsip ?? 0); ?>,
    laptopStats: <?php echo json_encode($laptopStats, 15, 512) ?>,
    isGuest: <?php echo e($isGuest ? 'true' : 'false'); ?>

  };
</script>

<div id="react-dashboard"></div>

<?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\projects\laptop-management-Deploy\resources\views/content/dashboard/dashboards-analytics.blade.php ENDPATH**/ ?>