<!-- ✅ Load jQuery dari CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Lanjutkan script bawaan -->
<?php echo app('Illuminate\Foundation\Vite')([
  'resources/assets/vendor/libs/popper/popper.js',
  'resources/assets/vendor/js/bootstrap.js',
  'resources/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js',
  'resources/assets/vendor/js/menu.js'
]); ?>

<!-- ✅ Load Select2 setelah jQuery -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<?php echo $__env->yieldContent('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/main.js']); ?>
<?php echo $__env->yieldPushContent('pricing-script'); ?>
<?php echo $__env->yieldContent('page-script'); ?>
<?php /**PATH C:\projects\laptop-management-Deploy\resources\views/layouts/sections/scripts.blade.php ENDPATH**/ ?>