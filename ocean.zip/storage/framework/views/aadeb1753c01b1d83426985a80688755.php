<!DOCTYPE html>
<html
  class="light-style layout-menu-fixed"
  data-theme="theme-default"
  data-assets-path="<?php echo e(asset('/assets') . '/'); ?>"
  data-base-url="<?php echo e(url('/')); ?>"
  data-framework="laravel"
  data-template="vertical-menu-laravel-template-free"
  style="background:#121212; color-scheme: dark;"> 

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />

  <title><?php echo $__env->yieldContent('title'); ?></title>

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/plnfavicon.ico')); ?>" />

  
  
  
  <script>
    (function() {
      const html = document.documentElement;
      const savedTheme = localStorage.getItem('theme') || 'light';

      // sementara sembunyikan body biar gak kedip
      document.documentElement.style.visibility = 'hidden';
      document.body && (document.body.style.display = 'none');

      if (savedTheme === 'dark') {
        html.classList.remove('light-style');
        html.classList.add('dark-style');
        html.setAttribute('data-theme', 'theme-dark');
        html.style.background = '#121212'; // dark bg langsung di-apply
        html.style.colorScheme = 'dark';
      } else {
        html.classList.remove('dark-style');
        html.classList.add('light-style');
        html.setAttribute('data-theme', 'theme-default');
        html.style.background = '#ffffff';
        html.style.colorScheme = 'light';
      }

      // pastikan tampil setelah DOM ready
      window.addEventListener('DOMContentLoaded', () => {
        document.body.style.display = '';
        html.style.visibility = 'visible';
      });
    })();
  </script>

  
  
  
  <?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/fonts/boxicons.scss',
    'resources/assets/vendor/scss/core.scss',
    'resources/assets/vendor/scss/theme-default.scss',
    'resources/assets/vendor/scss/_theme/_theme.scss',
    'resources/assets/vendor/scss/custom-override.scss',
    'resources/assets/css/demo.css',
  ]); ?>

  
  <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.jsx']); ?>

  
  <?php echo $__env->make('layouts/sections/styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  
  <?php echo $__env->yieldPushContent('styles'); ?>

  
  <?php echo $__env->make('layouts/sections/scriptsIncludes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <style>
    html,
    body {
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      transition: none !important;
    }

    #react-sidebar {
      flex-shrink: 0;
      min-height: 100vh;
      border-right: 1px solid #e0e0e0;
    }

    main {
      flex-grow: 1;
      min-width: 0;
    }
  </style>
</head>

<body data-active-menu="<?php echo e(request()->path()); ?>">
  <div class="d-flex">
    
    <div id="react-sidebar"></div>

    
    <main id="main-content">
      <?php echo $__env->yieldContent('layoutContent'); ?>
    </main>
  </div>

  
  <?php echo $__env->make('layouts/sections/scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\projects\laptop-management-Deploy\resources\views/layouts/commonMaster.blade.php ENDPATH**/ ?>