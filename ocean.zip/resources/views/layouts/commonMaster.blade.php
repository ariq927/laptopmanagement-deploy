<!DOCTYPE html>
<html
  class="light-style layout-menu-fixed"
  data-theme="theme-default"
  data-assets-path="{{ asset('/assets') . '/' }}"
  data-base-url="{{ url('/') }}"
  data-framework="laravel"
  data-template="vertical-menu-laravel-template-free"
  style="background:#121212; color-scheme: dark;"> {{-- cegah flicker putih pas dark mode --}}

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />

  <title>@yield('title')</title>

  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link rel="icon" type="image/x-icon" href="{{ asset('assets/img/favicon/plnfavicon.ico') }}" />

  {{-- ============================ --}}
  {{-- 🌙 Early Theme Init (Anti Flicker Final Version) --}}
  {{-- ============================ --}}
  <script>
    (function() {
      const html = document.documentElement;
      const savedTheme = localStorage.getItem('theme') || 'light';

      // sementara sembunyikan body biar gak kedip
      document.documentElement.style.visibility = 'hidden';
      document.body && (document.body.style.display = 'none');

      if (savedTheme === 'dark') {
        html.classList.remove('light-style');
        html.classList.add('dark-style');
        html.setAttribute('data-theme', 'theme-dark');
        html.style.background = '#121212'; // dark bg langsung di-apply
        html.style.colorScheme = 'dark';
      } else {
        html.classList.remove('dark-style');
        html.classList.add('light-style');
        html.setAttribute('data-theme', 'theme-default');
        html.style.background = '#ffffff';
        html.style.colorScheme = 'light';
      }

      // pastikan tampil setelah DOM ready
      window.addEventListener('DOMContentLoaded', () => {
        document.body.style.display = '';
        html.style.visibility = 'visible';
      });
    })();
  </script>

  {{-- ============================ --}}
  {{-- 🎨 CSS Vendor Styles (HARUS duluan) --}}
  {{-- ============================ --}}
  @vite([
    'resources/assets/vendor/fonts/boxicons.scss',
    'resources/assets/vendor/scss/core.scss',
    'resources/assets/vendor/scss/theme-default.scss',
    'resources/assets/vendor/scss/_theme/_theme.scss',
    'resources/assets/vendor/scss/custom-override.scss',
    'resources/assets/css/demo.css',
  ])

  {{-- ⚛️ React App --}}
  @viteReactRefresh
  @vite(['resources/js/app.jsx'])

  {{-- Include default Laravel template styles --}}
  @include('layouts/sections/styles')

  {{-- Styles tambahan --}}
  @stack('styles')

  {{-- Sneat JS helper --}}
  @include('layouts/sections/scriptsIncludes')

  <style>
    html,
    body {
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      transition: none !important;
    }

    #react-sidebar {
      flex-shrink: 0;
      min-height: 100vh;
      border-right: 1px solid #e0e0e0;
    }

    main {
      flex-grow: 1;
      min-width: 0;
    }
  </style>
</head>

<body data-active-menu="{{ request()->path() }}">
  <div class="d-flex">
    {{-- Sidebar React --}}
    <div id="react-sidebar"></div>

    {{-- Konten utama --}}
    <main id="main-content">
      @yield('layoutContent')
    </main>
  </div>

  {{-- Default scripts --}}
  @include('layouts/sections/scripts')
  @stack('scripts')
</body>
</html>
