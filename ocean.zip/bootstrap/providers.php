<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\MenuServiceProvider::class,
    App\Providers\RouteServiceProvider::class
];
